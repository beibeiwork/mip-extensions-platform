# mip-pc-ad

mip-pc-ad 广告位组件

标题|内容
----|----
类型|广告
支持布局|N/S
所需脚本|https://mipcache.bdstatic.com/extensions/platform/v1/mip-pc-ad/mip-pc-ad.js
        

## 示例

### 基本用法
```html
<mip-pc-ad class="test.gxq."></mip-pc-ad>
```

## 属性

### class

说明：pc广告组件
必选项：是
类型：字符串
取值范围：50位以内